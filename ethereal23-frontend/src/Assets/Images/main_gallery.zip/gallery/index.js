// import galleryImg1 from "./gallery_1.webp";
import galleryImg2 from "./gallery_2.webp";
import galleryImg3 from "./gallery_3.webp";
import galleryImg4 from "./gallery_4.webp";
// import galleryImg5 from "./gallery_5.webp";
import galleryImg6 from "./gallery_6.webp";
import galleryImg7 from "./gallery_7.webp";
// import galleryImg8 from "./gallery_8.webp";
// import galleryImg9 from "./gallery_9.webp";
// import galleryImg10 from "./gallery_10.webp";
import galleryImg11 from "./gallery_11.webp";
// import galleryImg12 from "./gallery_12.webp";
import galleryImg13 from "./gallery_13.webp";
import galleryImg14 from "./gallery_14.webp";
// import galleryImg15 from "./gallery_15.webp";
import galleryImg16 from "./gallery_16.webp";
// import galleryImg17 from "./gallery_17.webp";
import galleryImg18 from "./gallery_18.webp";
import galleryImg19 from "./gallery_19.webp";
import galleryImg20 from "./gallery_20.webp";
// import galleryImg21 from "./gallery_21.webp";
// import galleryImg22 from "./gallery_22.webp";
// import galleryImg23 from "./gallery_23.webp";

// export const galleryImgArr = [
//   //   galleryImg1,
//   galleryImg2,
//   galleryImg3,
//   galleryImg4,
//   //   galleryImg5,
//   galleryImg6,
//   galleryImg7,
//   //   galleryImg8,
//   //   galleryImg9,
//   //   galleryImg10,
//   galleryImg11,
//   //   galleryImg12,
//   galleryImg17,
//   galleryImg13,
//   galleryImg14,
//   //   galleryImg15,
//   galleryImg16,
//   //   galleryImg18,
//   galleryImg19,
//   galleryImg20,
//   //   galleryImg21,
//   galleryImg22,
//   //   galleryImg23,
// ];

export const galleryImgArr = [
  galleryImg2,
  galleryImg3,
  galleryImg4,
  galleryImg6,
  galleryImg7,
  galleryImg11,
  galleryImg14,
  galleryImg18,
  galleryImg13,
  galleryImg16,
  galleryImg19,
  galleryImg20,
  //   galleryImg22,
];
